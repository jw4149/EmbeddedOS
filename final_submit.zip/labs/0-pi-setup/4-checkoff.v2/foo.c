#include "rpi.h"
#include "foo.h"

void foo(void) {
    debug("PI: in foo\n");
}
