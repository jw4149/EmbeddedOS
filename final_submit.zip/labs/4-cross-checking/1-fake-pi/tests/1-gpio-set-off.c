#include "rpi.h"
void notmain(void) {
    gpio_set_off(20);
}
